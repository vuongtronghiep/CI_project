<?php
	class Trangchu extends CI_Controller{	
		public function __construct(){
			parent::__construct();
			$this->load->model('trangchu_model');
			$this->load->helper('form');
			$this->load->helper('url');	
			$this->load->helper('date');
			
		}	
		public function index(){
			$data['category'] = $this->trangchu_model->hienthicategory();
			$offset = $this->trangchu_model->tongsanpham();			 
			$data['sanphammoi'] = $this->trangchu_model->sanphammoinhat($offset);
			$offset2 = 9;
			$data['sanphamcu'] = $this->trangchu_model->sanphamcu($offset2);
			$data['sanphamnoibat'] = $this->trangchu_model->sanphamnoibat();
			$data['slider'] = $this->trangchu_model->slider();
			$this->load->view('index',$data);
		}

		public function dangky(){
			$this->form_validation->set_rules('tk', 'Tên tài khoản', 'required');
			$this->form_validation->set_rules('mk', 'Mật khẩu ', 'required');
			$this->form_validation->set_rules('ht', 'Họ và tên', 'required');
			$this->form_validation->set_rules('sdt', 'Di động', 'required|min_length[10]|max_length[11]');
			$this->form_validation->set_rules('dc', 'Địa chỉ', 'required');
			if ($this->form_validation->run() == FALSE) {
				$this->load->view('dangky');
			}else{	
				if($this->input->post('smit')){
					$data = array(
						'taikhoan' => $this->input->post('tk'),
						'matkhau' => $this->input->post('mk'),
						'fullname' => $this->input->post('ht'),
						'diachi' => $this->input->post('dc'),
						'sdt' => $this->input->post('sdt'),
						'gioitinh' => $this->input->post('gt'),
						'ngaysinh' => $this->input->post('ns'),
						'ngaytao' =>date("Y-m-d")
						);
					 $this->trangchu_model->themthanhvien($data);
					redirect('index/trangchu');	
				}
			}
		}

		
	}
 ?>