<?php
	class Qluser extends CI_Controller{
		public function __construct(){
			parent::__construct();
			$this->load->model('user_model');
			$this->load->helper('form');
			$this->load->helper('url');	
			$this->load->library("pagination");	
			
		}

		public function index(){
			//$data['user'] = $this->user_model->hienThiUser();
			//$this->load->view('admin/qluser',$data);

			$config['base_url']    = "admin/qluser/index";
			$config['total_rows']  = $this->user_model->countAll();
			$config['per_page']    = 2;	
			$config['prev_link']  = 'Lùi';
        	$config['next_link']  = 'Tiếp';
	
			$this->pagination->initialize($config);
			$limit = $config['per_page']    =2;
			$ofset = $this->uri->segment(4);	
			$data['user'] = $this->user_model->hienThiUser($limit,$ofset);

			$links = $this->pagination->create_links();
			$lks = $links;
			$lks = '<ul class="pagination">'.$links;
			$lks = str_replace('<a hr','<li><a hr', $lks);
			$lks = str_replace('</a>','</a></li>', $lks);
			$lks .= '</ul>';
			$data['links'] = $lks;	
			$this->load->view('admin/user', $data);	
		}

		public function xoathanhvien(){
			$taikhoan = $this->uri->segment('4');
			$this->user_model->xoaUser($taikhoan);
			redirect('admin/qluser');
		}
	}

 ?>