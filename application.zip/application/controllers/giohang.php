<?php
	class Giohang extends CI_Controller{
		public function __construct(){
			parent::__construct();
			$this->load->model('giohang_model');
			$this->load->library('cart');
			$this->load->library('table');

		}
		public function add(){
			$id = $this->uri->segment('3');
			$sanpham = $this->giohang_model->find($id);
			$data['category'] = $this->giohang_model->hienthicategory();
			$this->load->view('giohang',$data,TRUE);
			$data = array(
					'id' => $id,
					'name' => $sanpham->tensanpham,
					'price' => $sanpham->gia,
					'qty' =>1
				);
			$this->cart->insert($data);
			$this->load->view('giohang',$data);
		}

		public function delete(){

			$data['category'] = $this->giohang_model->hienthicategory();
			$this->load->view('giohang',$data,TRUE);
			$rowid = $this->uri->segment('3');
			$this->cart->update(array(
                        'rowid' => $rowid,
                        'qty' => 0
                    ));
  
               $this->load->view('giohang');
		}
		public function update(){
			if($this->uri->segment('2') == 'update'){
			$data['category'] = $this->giohang_model->hienthicategory();
			$this->load->view('giohang',$data,TRUE);
			$i = 1;
			foreach ($this->cart->contents() as $items) {
				$this->cart->update(array(
								'rowid'=>$items['rowid'],
								'qty'=>$this->input->post('qty'.$i)));
				$i++;
			}
			$this->load->view('giohang');
			}
		}

		public function deletegiohang(){
			$data['category'] = $this->giohang_model->hienthicategory();
			$this->load->view('giohang',$data,TRUE);
			$this->cart->destroy();
			$this->load->view('giohang');
		}
		public function thanhtoan(){
			  $ndata = array(
                'title'          => "Thanh toán",
                );
			  $this->load->view('thanhtoan',$ndata);
		}

		function save_order(){
            $customer = array(
                'hoten'          => $this->input->post('name'),
                'email'         => $this->input->post('email'),
                'dienthoai'         => $this->input->post('phone'),
                'diachi'       => $this->input->post('address'),
                'ngay_tao'          => date('Y-m-d')
            );
            $cust_id = $this->giohang_model->insert_thanhtoan($customer);
            
            $order = array(
                'ngay_order' => date('Y-m-d'),
                'id_khachhang' => $cust_id
            );
            
            $ord_id = $this->giohang_model->insert_order($order);
            
            if ($cart = $this->cart->contents()):
                foreach ($cart as $item):
                    $order_detail = array(
                    'order_id' => $ord_id,
                    'id_sanpham' => $item['id'],
                    'soluong' => $item['qty'],
                    'gia' => $item['price']
                );  
                $cust_id = $this->giohang_model->insert_order_detail($order_detail);
                endforeach;
            endif;
            $this->load->view('thanhcong');
        }     

	}
 ?>