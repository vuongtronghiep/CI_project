<?php
	class User_model extends CI_Model{
		public function __construct(){
			parent::__construct();
			$this->load->database();
		}

		public function countAll(){
			return $this->db->count_all('thanhvien');
		}
		public function hienThiUser($limit,$ofset){			
        	$this->db->select('*');
			$this->db->from('thanhvien');
            $this->db->limit($limit,$ofset);
			return $this->db->get();
		}

		public function xoaUser($taikhoan){
			$this->db->where('taikhoan', $taikhoan);
			$this->db->delete('thanhvien');
		}
	}
 ?>