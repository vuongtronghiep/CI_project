<?php
	if (!$this->session->userdata['logged_in']){
	header("location: http://localhost:8080/shoparsenal/admin/dangnhap/login");
	}
 ?>
<?php

	$this->load->view('admin/head.html');
 ?>
	<div class="main">
		<div class="thongtin"> Thông Tin</div>
		<div>&nbsp</div>
		<div class="panel panel-primary">
	        <div class="panel-heading">
	            <h3 class="panel-title">Thông Tin từ các Module</h3>
	        </div>
		    <div class="panel-body">
		        <table class="table">
					<thead>
					    <tr>
					        <th>Module</th>
					        <th>Nội Dung</th>
					        <th>Giá Trị</th>
					    </tr>
					</thead>
					<tbody>
					    <tr>
					        <td>Sản Phẩm</td>
					        <td>Tổng số sản phẩm</td>
					        <td> <?php echo $sanpham;	 ?></td>
					    </tr>
					    <tr>
					        <td>Danh Mục</td>
					        <td>Tổng số danh mục</td>
					        <td><?php echo $danhmuc;	 ?></td>
					    </tr>
					    <tr>
					        <td>User</td>
					        <td>Tổng số tài khoản user</td>
					        <td> <?php echo $user; ?></td>
					    </tr>
					     <tr>
					        <td>Admin</td>
					        <td>Tổng số tài khoản admin</td>
					        <td><?php echo $taikhoan;	 ?></td>
					    </tr>
					    <tr>
					        <td>Order</td>
					        <td>Tổng số Order</td>
					        <td><?php echo $order;	 ?></td>
					    </tr>
					    <tr>
					        <td>Đang cập nhật</td>
					        <td>Đang cập nhật</td>
					        <td>Đang cập nhật</td>
					    </tr>
					</tbody>
				 </table>
		    </div>
    	</div>
	</div>
	<footer> CopyRight &copy kenlilyArsenalShop</footer>
</body>
</html>