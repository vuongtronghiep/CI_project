<body>
    <section>
        <div id="ss">
        <h1>Cảm ơn bạn đã gửi thông tin thanh toán cho chúng tôi</h1>   
        <h1><a href="<?php echo base_url('trangchu') ?>">Quay lại Trang Chủ</a></h1>      
        </div>        
    </section>
</body>  
